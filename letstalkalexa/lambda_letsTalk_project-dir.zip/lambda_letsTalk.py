"""
This sample demonstrates a simple skill built with the Amazon Alexa Skills Kit.
The Intent Schema, Custom Slots, and Sample Utterances for this skill, as well
as testing instructions are located at http://amzn.to/1LzFrj6
For additional samples, visit the Alexa Skills Kit Getting Started guide at
http://amzn.to/1LGWsLG
"""

from __future__ import print_function
import string
from textblob import TextBlob
from random import *
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize

#nltk.download('stopwords')
exclude = set(string.punctuation)
flag = False

# --------------- Helpers that build all of the responses ----------------------

def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title': "SessionSpeechlet - " + title,
            'content': "SessionSpeechlet - " + output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }


def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


# --------------- Functions that control the skill's behavior ------------------

def get_welcome_response():
    """ If we wanted to initialize the session to have some attributes we could
    add those here
    """

    session_attributes = {}
    card_title = "Welcome"
    speech_output = "Sure! Let's talk. How are you doing today? "
    reprompt_text = "Are you alright?"
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def handle_session_end_request():
    card_title = "Session Ended"
    speech_output = "I am glad you chose to talk to me today. " \
                    "Have a nice day! "
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(
        card_title, speech_output, None, should_end_session))


def create_current_emotion_attributes(current_emotion):
    return {"currentEmotion": current_emotion}


def create_person_involved_attributes(person_involved):
    return {"personInvolved": person_involved}


def create_emotion_cause_attributes(emotion_cause):
    return {"emotionCause": emotion_cause}


def set_emotion_in_session(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """

    card_title = intent['name']
    session_attributes = {}
    should_end_session = False

    if 'Emotion' in intent['slots']:
        current_emotion = intent['slots']['Emotion']['value']
        session_attributes = create_current_emotion_attributes(current_emotion)
        text1 = "And did a friend or family member make you feel " + \
                        current_emotion + \
                        " today?"
        text2 = "Who made you "+current_emotion + " today? A friend, relative or . . . a love interest involved perhaps?"
        output = [text1, text2]
        ch = randint(0,1)
        speech_output = output[ch]
        reprompt_text = "Is someone to be held responsible for this mood?"
    else:
        speech_output = "I didn't quite catch that. " \
                        "You can tell me how you feel today."
        reprompt_text = "Can you repeat that?" \
                        "I'm here for you."
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def set_response_in_session(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """
    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False

    speech_output = "So, who might that be?"
    reprompt_text = "So, who might that be?"
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def set_person_in_session(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """

    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False

    if session.get('attributes', {}) and "currentEmotion" in session.get('attributes', {}):
        current_emotion = session['attributes']['currentEmotion']
        # if 'Person' in intent['slots']:
        person_involved = intent['slots']['Person']['value']
        session_attributes.update(create_person_involved_attributes(person_involved))
        text1 = "And how exactly did " + person_involved + \
                        " make you feel " + current_emotion + \
                        "?"
        text2 = "What did " + person_involved + \
            " do to make you feel " + current_emotion + "?"
        output = [text1, text2]
        ch = randint(0,1)
        speech_output = output[ch]
        reprompt_text = "what happened today? Why are you " + current_emotion

    else:
        speech_output = "I didn't quite catch that. " + \
                        "what exactly happened with " + person_involved + \
                        "to make you feel " + current_emotion + \
                        " today?"

        reprompt_text = "I didn't quite catch that. " + \
                        "what exactly happened with " + person_involved + \
                        "to make you feel " + current_emotion + \
                        " today?"

    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def ask_cause_in_session(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """

    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False
    flag = False
    values = []
    # for k,v in session_attributes:
    # values


    if session.get('attributes', {}) and "currentEmotion" in session.get('attributes', {}):
        current_emotion = session['attributes']['currentEmotion']
    speech_output = "Oh so why are you feeling " + current_emotion + \
                    "?"
    reprompt_text = "Oh so why are you feeling " + current_emotion + \
                    " ?"

    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def get_text_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0:
        return 'positive'
    elif analysis.sentiment.polarity == 0:
        return 'neutral'
    else:
        return 'negative'


def parse_pronouns(text):
    #rep = {"my": "your", "I": "you", "our": "your", "we": "you"}
    pron = ["my", "I", "our", "we"]
    chg = ["your", "you", "your", "you"]
    for i in range(len(pron)):
        new_text = string.replace(text, pron[i], chg[i])
    return new_text


def set_cause_in_session(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """

    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False
    speech_output = " "

    if session.get('attributes', {}) and "currentEmotion" in session.get('attributes', {}):
        current_emotion = session['attributes']['currentEmotion']

    if 'Cause' in intent['slots']:
        emotion_cause = intent['slots']['Cause']['value']
        cause = parse_pronouns(emotion_cause)
        session_attributes.update(create_emotion_cause_attributes(cause))

    if flag == False:
        speech_output = "So " + cause + \
                        " makes you feel " + session_attributes["currentEmotion"]

        reprompt_text = "Oh so " + cause + \
                        " made you feel " + session_attributes["currentEmotion"] + \
                        " today?"

    else:
        person_involved = session_attributes["personInvolved"]
        speech_output = "So " + cause + " and "+ person_involved + " are mostly why you are feeling " + current_emotion + \
                         " today?"
        reprompt_text = "So " + cause + " and "+ person_involved + " are mostly why you are feeling " + current_emotion + \
                         " today?"

    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def mention_sentiment(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """

    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False

    if session.get('attributes', {}) and "emotionCause" in session.get('attributes', {}):
        emotion_cause = session['attributes']['emotionCause']

    sentiment = get_text_sentiment(emotion_cause)

    if sentiment == "positive":
        output = ["You seemed to have had a really good day.", "Sure does seem like a good day to me!"]
        ch = randint(0,1)
        speech_output = output[ch]
        reprompt_text = "You seemed to have had a really good day."

    else:
        output = ["Your day doesn't seem to be going so great. Do you need some motivation or would you like me to crack a joke?", "Yikes! You could do with a joke or some motivation."]
        ch = randint(0, 1)
        speech_output = output[ch]
        reprompt_text = "Your day doesn't seem to be going so great. Do you need some motivation or would you like me to crack a joke?"
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def crack_joke(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """
    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False
    jokes = ["Who was the roundest knight at King Arthur's table? . . . Sir. Cumference.", "What kind of shorts do clouds wear? . . . Thunderpants.",
             "I don't trust people with graph paper. . . They're always plotting something.", "What's worse than finding a worm in your apple? . . . Finding half a worm.",
             "Why did the football coach shake the vending machine? . . . Because he needed a quarterback."]

    ch = randint(0, len(jokes)-1)
    speech_output = jokes[ch]
    reprompt_text = jokes[ch]

    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def motivate_me(intent, session):
    """ Sets the emotion in the session and prepares the speech to reply to the
    user.
    """
    card_title = intent['name']
    session_attributes = session["attributes"]
    should_end_session = False
    quotes = ["Nothing is impossible, the word itself says I'm possible. . . By Audrey Hepburn", "Life is 10% what happens to me and 90% of how I react to it. . . By Charles Swindoll",
             "If you look at what you have in life, youll always have more. If you look at what you dont have in life, youll never have enough. . . By Oprah Winfrey", "Remember no one can make you feel inferior without your consent. . . By Eleanor Roosevelt",
             "Only I can change my life. No one can do it for me. . . By Carol Burnett"]

    ch = randint(0, len(quotes)-1)
    speech_output = quotes[ch]
    reprompt_text = quotes[ch]

    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))

# --------------- Events ------------------

def on_session_started(session_started_request, session):
    """ Called when the session starts """
    session_attributes = {}

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])


def on_launch(launch_request, session):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response()


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "IfeelIntent":
        return set_emotion_in_session(intent, session)
    elif intent_name == "responseIntent":
        return set_response_in_session(intent, session)
    elif intent_name == "personInvolved":
        return set_person_in_session(intent, session)
    elif intent_name == "noPersonInvolved":
        return ask_cause_in_session(intent, session)
    elif intent_name == "displaySentiment":
        return mention_sentiment(intent, session)
    elif intent_name == "crackJoke":
        return crack_joke(intent, session)
    elif intent_name == "motivate":
        return motivate_me(intent, session)
    elif intent_name == "emotionCause":
        return set_cause_in_session(intent, session)
    elif intent_name == "AMAZON.HelpIntent":
        return get_welcome_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    else:
        raise ValueError("Invalid intent")


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.
    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here


# --------------- Main handler ------------------

def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")

    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])

    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'])
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])